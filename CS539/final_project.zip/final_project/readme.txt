
To run it:
1) From your Terminal or PowerShell, run "python3 -m http.server 8888"(或python -m http.server 8888端口名可自定义)
2) Go to your browser (I recommend Chrome) and open http://localhost:8888(对应端口名)

Cheers,
Barry